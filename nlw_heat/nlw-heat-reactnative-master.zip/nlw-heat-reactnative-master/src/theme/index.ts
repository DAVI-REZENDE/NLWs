import { COLORS } from "./colors";
import { FONTS } from "./fonts";

export { COLORS, FONTS };